# Rolling_Dice-Money_Game
A program design to make user guess the outcome of rolling dice.
